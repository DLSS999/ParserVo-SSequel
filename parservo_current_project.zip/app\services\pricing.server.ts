export type PricingInput = {
  supplierPrice: number;
  currency: string;
  eurRate: number;
  plnRate: number;
  markupPercent: number;
  roundingRule: string;
  compareAtEnabled: boolean;
  compareAtFormula?: string;
};

export function toDecimalNumber(value: unknown, fallback = 0) {
  if (typeof value === "number" && Number.isFinite(value)) return value;

  const raw = String(value ?? "")
    .trim()
    .replace(/\s+/g, "")
    .replace(/,/g, ".")
    .replace(/[^\d.-]/g, "");

  const parsed = Number(raw);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function roundUp(value: number, step: number) {
  if (!Number.isFinite(value) || value <= 0) return 0;
  return Math.ceil(value / step) * step;
}

function roundMoney(value: number) {
  if (!Number.isFinite(value) || value <= 0) return 0;
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

function getCurrencyRate(currency: string, eurRate: number, plnRate: number) {
  const normalized = String(currency || "").toUpperCase().trim();
  const eur = toDecimalNumber(eurRate, 45);
  const pln = toDecimalNumber(plnRate, 12.5);

  if (normalized === "EUR" || normalized === "€") return eur;
  if (normalized === "PLN" || normalized === "ZŁ" || normalized === "ZL") return pln;

  return 1;
}

function getCinqCoefficient(costPriceUah: number) {
  if (costPriceUah <= 800) return 2.7;
  if (costPriceUah <= 1200) return 2.25;
  if (costPriceUah <= 1800) return 1.75;
  if (costPriceUah <= 2500) return 1.37;
  if (costPriceUah <= 5000) return 1.32;
  if (costPriceUah <= 10000) return 1.27;
  return 1.22;
}

export function calculatePricing(input: PricingInput) {
  const supplierPrice = toDecimalNumber(input.supplierPrice, 0);
  const exchangeRateUsed = getCurrencyRate(input.currency, input.eurRate, input.plnRate);

  const rawCostPriceUah = supplierPrice * exchangeRateUsed;
  const costPriceUah = roundMoney(rawCostPriceUah);
  const coefficient = getCinqCoefficient(costPriceUah);
  const salePriceUah = roundUp(costPriceUah * coefficient, 10);

  // Compare-at price logic is intentionally disabled until a separate CINQ rule is approved.
  // Required Shopify fields for the current ТЗ are:
  // - Cost per item = costPriceUah
  // - Price = salePriceUah
  const compareAtPriceUah = null;

  return {
    exchangeRateUsed,
    costPriceUah,
    salePriceUah,
    compareAtPriceUah,
  };
}
